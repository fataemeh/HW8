//فاطمه رضوانی زاده
//40223034
#include<stdio.h>
struct time
{
int min;
int sec;
};

struct runner
{
char firstName[20];
char lastName[20];
int ID;
struct time *record;
struct time runningTime;
};


int main()
{
int n , i=0 , j=0 , k=0 , z=0, p=0, winrec;
char win ;

printf("enter the number of players");
scanf("%d" , &n);

struct runner a[n];

for(i=0;i<n;i++)
{
    printf("enter the informations of player %d\n" , i+1);   //فرض این است که کاربر به ترتیب همه را وارد میکند
    scanf("%s" , &a[i].firstName);
    scanf("%s" , &a[i].lastName);
    scanf("%d" , &a[i].ID);
    scanf("%d" , &a[i].record->min);
    scanf("%d" , &a[i].record->sec);
    scanf("%d" , &a[i].runningTime.min);
    scanf("%d" , &a[i].runningTime.sec);
}

win=strcat(a[j].firstName , a[j].lastName);   //برنده مسابقه
for(j=0 ;j<n,j++)
{
    if(a[j+1].runningTime.min < a[j].runningTime.min)
        win=strcat(a[j+1].firstName , a[j+1].lastName);

    else if((a[j+1].runningTime.min == a[j].runningTime.min)  && (a[j+1].runningTime.sec < a[j].runningTime.sec))
        win=strcat(a[j+1].firstName , a[j+1].lastName);
    printf
}
printf("the winner player is: %s\n" , win);


if(a[j+1].runningTime.min < a[j+1].record->min )  //رکورد جدید
    printf("the winner managed to set a new record\n");

else if((a[j+1].runningTime.min == a[j+1].record->min) && (a[j+1].runningTime.sec < a[j+1].record->sec))
    printf("the winner managed to set a new record\n");

else
    printf("the winner failed to set a new record\n");


for(k=0;k<n,k++)                                  //بهترین رکورد
{
    if(a[j+1].runningTime.min < a[k].record->min)
        count++;

    else if((a[j+1].runningTime.min == a[k].record->min) && (a[j+1].record->sec < a[j].record->sec))
        count++;
}
if(count!=0)
    printf("the winner set the best time\n");
else
    printf("the winner failed to set the best record\n");

for(p=0;p<n;p++)                     //لیست بازیکنان
{
    if(a[p+1].runningTime.min < a[p].runningTime.min)
    {
        temp=a[p];
        a[p]=a[p+1];
        a[p+1]=temp;
    }   

    else if((a[p+1].runningTime.min) == (a[p].runningTime.min)  && (a[p+1].runningTime.sec < a[p].runningTime.sec))
    {
        temp=a[p];
        a[p]=a[p+1];
        a[p+1]=temp;
    }   

printf("player\tname\tID\trunning time\trecord\n");
for(p=0;p<n;p++)
printf("%d\t%c\t%d\d%d\t%d\n" , p+1 , strsat(a[p].firstName , a[p].lastName) , a[p].ID , strcat(a[p].runningTime.min) , (a[p].runningTime.sec) , strcat(a[p].record->min) , (a[p].record->sec));
    










}